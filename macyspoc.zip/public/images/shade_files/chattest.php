processJson({
"key1": "true",
"key2": true,
"key3": true,
"key4": false,
"key5": "184"
})