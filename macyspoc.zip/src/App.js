import React from 'react';
import Breadcrumb from 'react-bootstrap/Breadcrumb';
import Button from 'react-bootstrap/Button';
import { IoIosArrowDown, IoIosStar, IoIosStarHalf } from "react-icons/io";
import './App.scss';
class App extends React.Component {
  render() {
    return (
      <div>
        <div className='macysTemplate'>
          <div className='macysBreadcrumb'>
            <Breadcrumb className='breadcrumbs-container'>
              <Breadcrumb.Item href="#">Macy's</Breadcrumb.Item>
              <Breadcrumb.Item href="#">Beauty</Breadcrumb.Item>
              <Breadcrumb.Item active>Foundation</Breadcrumb.Item>
            </Breadcrumb>
          </div>
          <div className='macysBody'>
            <div className='row'>
              <div className='col-md-1'>
                <div className='scroller-wrap'>
                  <img className='bobbibrownImg' src="images/bobbi-brown.jpg" height='75px' alt='bobbi-brown' />
                  <img src="images/foundation-color.jpg" width='60px' height='75px' alt='foundation-color' />
                  <img src="images/skin-color.jpg" width='60px' height='75px' alt='skin-color' />
                  <img src="images/bobbi-brown.jpg" width='60px' height='75px' alt='bobbi-brown' />
                  <div className='downArrow'><IoIosArrowDown /></div>
                </div>
              </div>
              <div className='col-md-3'>
                <img src="images/bobbi-brown.jpg" height='500px' alt='bobbi-brown' />
              </div>
              <div className='col-md-6 productDesc'>
                <p><b>Bobbi Brown</b></p>
                <p className='productTitle'>Skin Long-Wear Weightless Foundation SPF 15, 1-oz.</p>
                <p><IoIosStar /><IoIosStar /><IoIosStar /><IoIosStar /><IoIosStarHalf />
                  <u>479 Reviews</u>
                  <u className='questions'>1 Questions & 0 Answers</u>
                </p>
                <p>$49.00</p>
                <p className='vendorDesc'>4 interest-free payments of $12.25 with <span className='vendorlogo'>Klarna.</span> <u>Learn More</u></p>
                <div><span className='shippingCost'>Free ship at $25</span> <u className='vendorDetails'>Details</u></div>
                <div className='giftpurchase'><span className='shippingCost'>Free gift with purchase</span> <u className='vendorDetails'>Details</u></div>
                <p><img src='images/shade.png' alt='shade' height='50px' /></p>
                <p>Color: <b>Alabaster (C-004) Light beige with a white hint and pink undertone.</b></p>
                <p><img src='images/colorshades.png' alt='color-shades' width='700px' /></p>
                <div className='quantity'>
                  <span>Qty: <b>1</b></span>
                  <table border='1px'>
                    <thead>
                      <tr>
                        <td width='60px' height='38px'>-</td>
                        <td width='60px' height='38px'>+</td>
                      </tr>
                    </thead>
                  </table>
                </div>
                <div className='buttons'>
                  <Button className='bagButton'>Add to Bag</Button>
                  <Button className='listButton'>Add to List</Button>
                </div>
                <p className='horizental-Line'></p>
                <div className='shipit'>
                  <div><input type='radio' checked /></div>
                  <div className='content'>
                    <p><b>Ship it</b> to <u>10001</u></p>
                    <p><small>In stock: Usually ships within 2 business days.</small></p>
                    <p><b>Same-Day Delivery</b> eligible. Order by 12PM.</p>
                  </div>
                </div>
                <div className='pickup'>
                  <div><input type='radio' /></div>
                  <div className='content'>
                    <p><b>Pick Up Today</b> at <u>Herald Square</u></p>
                    <p><small>Order by 4:00 PM for</small> <b>Curbside</b> <small>or</small> <b>In Store Pickup.</b></p>
                    <p><u>See Store Details</u></p>
                  </div>
                </div>
              </div>
              <div className='col-md-2 customerRecommandations'>
                <div>
                  <p><b>Customers Also</b></p>
                  <p><b>Shopped</b></p>
                  <p><img src='images/recom1.png' alt='recommandation1' width='135px' height='156px' /></p>
                  <p><b>Bobbi Brown</b></p>
                  <p>Skin Foundation...</p>
                  <p>$50.00</p>
                  <p><IoIosStar /><IoIosStar /><IoIosStar /><IoIosStar /><IoIosStarHalf />(1082)</p>
                </div>
                <div>
                  <p><b>Customers Also</b></p>
                  <p><b>Shopped</b></p>
                  <p><img src='images/recom2.png' alt='recommandation2' width='135px' height='156px' /></p>
                  <p><b>Bobbi Brown</b></p>
                  <p>Instant Full-Cover...</p>
                  <p>$32.00</p>
                  <p><IoIosStar /><IoIosStar /><IoIosStar /><IoIosStar /><IoIosStarHalf />(1082)</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default App;
